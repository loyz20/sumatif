const express = require('express');
const { controller: ptkController } = require('../../modules/ptk');
const { controller: ptkRiwayatController } = require('../../modules/ptkRiwayat');
const { validateRequest } = require('../../middlewares/validation.middleware');
const { authorize } = require('../../middlewares/authorize.middleware');
const { idParamsSchema } = require('../../validations/base.schema');
const {
	createPtkSchema,
	updatePtkSchema,
	listPtkQuerySchema,
	createPtkRiwayatPendidikanSchema,
	importPtkSchema,
} = require('../../validations/ptk.schema');

const router = express.Router();

router.get('/', authorize('admin', 'guru', 'guru_bk'), validateRequest(listPtkQuerySchema, 'query'), ptkController.list);
router.get('/stats', authorize('admin', 'guru', 'guru_bk'), ptkController.stats);
router.post('/import', authorize('admin'), validateRequest(importPtkSchema), ptkController.importData);
router.post('/', authorize('admin'), validateRequest(createPtkSchema), ptkController.create);
router.get('/:id', authorize('admin', 'guru', 'guru_bk'), validateRequest(idParamsSchema, 'params'), ptkController.detail);
router.put('/:id', authorize('admin'), validateRequest(idParamsSchema, 'params'), validateRequest(updatePtkSchema), ptkController.update);
router.delete('/:id', authorize('admin'), validateRequest(idParamsSchema, 'params'), ptkController.remove);
router.get('/:id/riwayat-pendidikan', authorize('admin', 'guru', 'guru_bk'), validateRequest(idParamsSchema, 'params'), ptkRiwayatController.listPendidikan);
router.post(
	'/:id/riwayat-pendidikan',
	authorize('admin'),
	validateRequest(idParamsSchema, 'params'),
	validateRequest(createPtkRiwayatPendidikanSchema),
	ptkRiwayatController.createPendidikan
);
router.get('/:id/riwayat-kepangkatan', authorize('admin', 'guru', 'guru_bk'), validateRequest(idParamsSchema, 'params'), ptkRiwayatController.listKepangkatan);

module.exports = router;
